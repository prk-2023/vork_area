# Why Rust — A Systems Programmer's Perspective

Focused Typst/Touying presentation on Rust's *core technical merits* for
an audience of senior kernel and C developers (5–30+ years experience).

## What this covers

| Section | Content |
|---|---|
| 1. The problem | Memory bug statistics with references; the C/GC/Rust design space |
| 2. Ownership | Three rules; UAF comparison (C vs Rust); RAII / goto-cleanup elimination |
| 3. Borrowing & Lifetimes | Aliasing rules; dangling pointer prevention; data-race freedom proof |
| 4. Compiler checks | `#[must_use]`, exhaustive `match`, `Option<T>` vs NULL, unsafe quarantine |
| 5. Modern concepts | Traits; zero-cost abstractions; `Result`/`?`; fearless concurrency |
| 6. Performance | Aliasing advantage; benchmark data; industrial deployments |
| 7. Ecosystem | Typst itself as a Rust meta-argument; toolchain landscape |
| References | Academic (RustBelt, formal methods) + industry sources |

## Build

```bash
# Install Typst (one-time)
curl -fsSL https://typst.app/install.sh | sh
# or: cargo install typst-cli

# Compile
typst compile rust-features.typ rust-features.pdf

# Live preview (recompiles on save)
typst watch rust-features.typ rust-features.pdf
```

## Recommended editor: VS Code + Tinymist

Install the **Tinymist Typst** extension — live preview, hover docs, syntax highlight.

## Key references cited in the slides

- **RustBelt** (Jung et al., POPL 2018): first machine-checked formal proof
  that Rust's type system is sound, including `Send`/`Sync` for thread safety.
  https://plv.mpi-sws.org/rustbelt/popl18/

- **RustBelt Meets Relaxed Memory** (Dang et al., POPL 2020): extends the
  proof to C11 relaxed-memory atomics.

- **Microsoft MSRC** (2019): ~70% of CVEs are memory safety bugs.

- **Linux Security Summit** (Gaynor & Thomas, 2019): ~67% of kernel CVEs
  are memory safety violations.

- **Cloudflare Pingora** (2022): Rust HTTP proxy, 1 trillion req/day,
  ~70% lower memory vs Nginx.

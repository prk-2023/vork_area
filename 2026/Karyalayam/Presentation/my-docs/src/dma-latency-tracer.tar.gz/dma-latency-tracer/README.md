# dma-latency-tracer

An Aya-based eBPF tool that measures `dma_map_sg` call latency on a system
running a **Mellanox ConnectX-5** NIC (PCIe Gen 4 card in a Gen 3 host slot),
with both ports connected via a **DAC crossover cable** and each port bound to
a separate **Linux network namespace** to force real physical traffic.

---

## Physical setup

```
┌──────────────────────────────────────────┐
│  Host motherboard  (PCIe Gen 3.0 x16)   │
│                                          │
│  ┌────────────────────────────────────┐  │
│  │  ConnectX-5 100GbE (PCIe Gen 4)   │  │
│  │  Port 0 ──╮                        │  │
│  │  Port 1 ──╯  DAC crossover cable   │  │
│  └────────────────────────────────────┘  │
└──────────────────────────────────────────┘

Kernel namespaces:
  ns0 → Port 0 (enp6s0f0)  192.168.100.1/24
  ns1 → Port 1 (enp6s0f1)  192.168.100.2/24
```

Card negotiates **PCIe Gen 3** link speed (limited by host slot).  
Expected throughput: ~85–95 Gbps sustained bidirectional.

---

## Project structure

```
dma-latency-tracer/
├── Cargo.toml                        workspace root
├── rust-toolchain.toml               pins nightly (required for build-std)
│
├── dma-latency-tracer-common/        ← shared types (no_std + std)
│   ├── Cargo.toml
│   └── src/lib.rs                    DmaEvent, HIST_BOUNDS_NS, hist_bucket()
│
├── dma-latency-tracer-ebpf/          ← eBPF programs (bpfel-unknown-none)
│   ├── Cargo.toml
│   ├── build.rs                      checks bpf-linker on PATH
│   ├── .cargo/config.toml            sets BPF target + BTF flags
│   └── src/main.rs                   kprobe/kretprobe on dma_map_sg
│
└── dma-latency-tracer/               ← userspace loader + reporter
    ├── Cargo.toml
    ├── build.rs  ← THE KEY FILE      cross-compiles eBPF, copies to OUT_DIR
    └── src/main.rs                   loads BPF, reads ring buf, prints hist
```

No `xtask` crate.  A single `cargo build` compiles everything.

---

## Prerequisites

### 1. Rust nightly + rust-src

```bash
rustup toolchain install nightly --component rust-src rustfmt clippy
```

### 2. bpf-linker

```bash
# Uses the LLVM shared library that ships with rustup (x86_64 Linux only).
cargo install bpf-linker

# If you are on a non-x86_64 host or the above fails, use external LLVM:
# https://github.com/aya-rs/bpf-linker#external-llvm
```

### 3. Kernel requirements

| Requirement | Minimum | Notes |
|---|---|---|
| Kernel version | 5.8 | `BPF_MAP_TYPE_RINGBUF` |
| `CONFIG_DEBUG_INFO_BTF` | y | Required for CO-RE |
| `CONFIG_KPROBES` | y | kprobe/kretprobe |
| `CONFIG_BPF_SYSCALL` | y | eBPF syscall |

Check:
```bash
zcat /proc/config.gz | grep -E 'CONFIG_DEBUG_INFO_BTF|CONFIG_KPROBES|CONFIG_BPF'
```

### 4. Network namespace setup (ConnectX-5 crossover)

```bash
# Adjust interface names to match your system (ip link show | grep enp)
PORT0=enp6s0f0
PORT1=enp6s0f1

sudo ip netns add ns0
sudo ip netns add ns1
sudo ip link set $PORT0 netns ns0
sudo ip link set $PORT1 netns ns1

sudo ip netns exec ns0 ip addr add 192.168.100.1/24 dev $PORT0
sudo ip netns exec ns0 ip link set $PORT0 up
sudo ip netns exec ns0 ethtool -A $PORT0 rx on tx on

sudo ip netns exec ns1 ip addr add 192.168.100.2/24 dev $PORT1
sudo ip netns exec ns1 ip link set $PORT1 up
sudo ip netns exec ns1 ethtool -A $PORT1 rx on tx on

# Verify physical link (should show "Link detected: yes")
sudo ip netns exec ns0 ethtool $PORT0 | grep -E 'Speed|Duplex|Link'
```

### 5. Verify PCIe link speed

```bash
# Find the PCIe device (Mellanox/NVIDIA VID = 15b3)
lspci | grep -i mellanox
# Example output: 06:00.0 Ethernet controller: Mellanox Technologies MT28800 ...

# Check negotiated link speed (should show Gen3 x16 or similar)
sudo lspci -s 06:00.0 -vvv | grep -E 'LnkSta:|LnkCap:'
# LnkCap: ... Speed 16GT/s (Gen4), Width x16
# LnkSta: ... Speed 8GT/s (Gen3), Width x16   ← limited by host slot
```

---

## Build

```bash
# One command builds both the eBPF bytecode and the userspace binary.
cargo build

# Release build (optimised BPF + optimised userspace):
cargo build --release
```

The `build.rs` in `dma-latency-tracer/` drives the eBPF cross-compilation
automatically.  You do not need to run any separate step.

---

## Run

```bash
# Generate traffic first (in background terminals):
sudo ip netns exec ns0 iperf3 -s &
sudo ip netns exec ns1 iperf3 -c 192.168.100.1 -t 120 -P 8

# Run the tracer (requires CAP_BPF / root):
sudo RUST_LOG=info cargo run -- \
    --interval 5 \
    --min-latency-us 2 \
    --filter-comm iperf3

# Or with the release binary:
sudo RUST_LOG=info ./target/release/dma-latency-tracer \
    --interval 5 \
    --filter-comm mlx5
```

### CLI options

| Flag | Default | Description |
|---|---|---|
| `--interval <s>` | 5 | Report histogram every N seconds |
| `--min-latency-us <µs>` | 0 | Print individual events only above this threshold |
| `--filter-comm <str>` | (none) | Only show events from processes matching this substring |
| `--max-events <n>` | 50 | Cap on individually logged events before suppression |

---

## Sample output

```
[INFO] DMA latency tracer attached. Reporting every 5s.
[INFO] Setup: ConnectX-5 (PCIe Gen4 card @ Gen3 host slot) + DAC crossover cable

[INFO] [cpu=03] pid= 12345 comm=iperf3           nents=  16 dir=TO_DEVICE      latency=   1.842 µs
[INFO] [cpu=07] pid= 12345 comm=iperf3           nents=  32 dir=TO_DEVICE      latency=   2.201 µs

[INFO] ═══════════════════════════════════════════════════════════════
[INFO]   dma_map_sg latency histogram  (total events: 48291)
[INFO]   System: ConnectX-5 PCIe Gen4 card | Gen3 host slot | DAC crossover
[INFO] ───────────────────────────────────────────────────────────────
[INFO]     range          count        %  dist
[INFO]   0 – 500 ns       2134     4.42%  |████░░░░░░░░░░░░░░░░░░░░░░░░░░|
[INFO] 500 – 1 µs         5891    12.20%  |████████████░░░░░░░░░░░░░░░░░░|
[INFO]   1 – 2 µs        18432    38.17%  |██████████████████████████████|
[INFO]   2 – 3 µs        14201    29.41%  |███████████████████████░░░░░░░|
[INFO]   3 – 5 µs         5912    12.24%  |████████████░░░░░░░░░░░░░░░░░░|
[INFO]   5 – 7.5 µs       1102     2.28%  |██░░░░░░░░░░░░░░░░░░░░░░░░░░░░|
[INFO] 7.5 – 10 µs          401     0.83%  |░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░|
...
[INFO] ───────────────────────────────────────────────────────────────
[INFO]   Fast ( < 2 µs):  26457  (54.8%)  — expected for warm IOMMU TLB
[INFO]   Slow (> 30 µs):     38   (0.1%)  — check IOMMU pressure / C-states
[INFO] ───────────────────────────────────────────────────────────────
[INFO]    pid  comm              count      avg µs      min µs      max µs
[INFO]  12345  iperf3            48291       1.923       0.312      87.441
```

---

## Interpreting results for ConnectX-5 + PCIe Gen 3

| Observation | Likely cause | Action |
|---|---|---|
| Most latencies < 2 µs | IOMMU TLB warm, normal path | ✓ |
| Spike to > 10 µs | IOMMU TLB miss (page walk) | Increase IOMMU page size or disable IOMMU for this device |
| Spike to > 50 µs | CPU frequency scaling (C-states) | `cpupower frequency-set -g performance` |
| Slow events correlated with high `nents` | Large scatter-gather lists | Tune `net.core.optmem_max`, or reduce MTU fragmentation |
| Latency bimodal (fast + slow clusters) | NUMA misplacement | Pin mlx5 IRQs to CPUs local to PCIe slot |

### PCIe Gen 3 vs Gen 4 note

The ConnectX-5 supports PCIe Gen 4 (16 GT/s) but is limited to Gen 3 (8 GT/s)
by the host slot.  This halves the maximum PCIe bandwidth but does **not**
directly increase DMA latency for individual scatter-gather operations.  The
primary latency determinants are:

- IOMMU translation (dominant for small `nents`)
- CPU NUMA distance to the PCIe root complex
- CPU C-state depth during the DMA operation

---

## BPF map sizes and tuning

| Map | Type | Default size | Notes |
|---|---|---|---|
| `START_MAP` | `HashMap` | 4 096 entries | Increase if you see `dma_map_sg_enter error: 4` in logs |
| `EVENTS` | `RingBuf` | 4 MiB | Increase if events are dropped under high load |

To change sizes, edit `dma-latency-tracer-ebpf/src/main.rs`:
```rust
static START_MAP: HashMap<u64, EntryData> = HashMap::with_max_entries(8192, 0);
static EVENTS: RingBuf = RingBuf::with_byte_size(8 * 1024 * 1024, 0);
```

---

## Cleaning up

```bash
# Remove namespaces
sudo ip netns del ns0
sudo ip netns del ns1

# The BPF programs are automatically detached when the tracer exits.
```

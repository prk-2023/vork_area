//! Userspace loader and reporter for the DMA latency tracer.
//!
//! Usage
//! -----
//!   sudo RUST_LOG=info cargo run --bin dma-latency-tracer -- \
//!       --interval 2 --min-latency-us 1
//!
//! Network namespace setup (ConnectX-5 crossover DAC, two ports):
//! ---------------------------------------------------------------
//!   # Create namespaces
//!   ip netns add ns0
//!   ip netns add ns1
//!
//!   # Bind each mlx5 port to its namespace (replace enp<X>s0f{0,1} as needed)
//!   ip link set enp6s0f0 netns ns0
//!   ip link set enp6s0f1 netns ns1
//!
//!   # Assign addresses and bring up
//!   ip netns exec ns0 ip addr add 192.168.100.1/24 dev enp6s0f0
//!   ip netns exec ns0 ip link set enp6s0f0 up
//!   ip netns exec ns1 ip addr add 192.168.100.2/24 dev enp6s0f1
//!   ip netns exec ns1 ip link set enp6s0f1 up
//!
//!   # Generate traffic that traverses the DAC cable
//!   ip netns exec ns0 iperf3 -s &
//!   ip netns exec ns1 iperf3 -c 192.168.100.1 -t 60 -P 8
//!
//! Then run the tracer in the root namespace (kprobes are global):
//!   sudo RUST_LOG=info ./dma-latency-tracer

use std::{
    collections::HashMap,
    os::fd::AsRawFd,
    sync::{
        atomic::{AtomicBool, Ordering},
        Arc,
    },
    time::Duration,
};

use anyhow::{Context, Result};
use aya::{
    include_bytes_aligned,
    maps::RingBuf,
    programs::{KProbe, KRetProbe},
    Ebpf,
};
use aya_log::EbpfLogger;
use clap::Parser;
use log::{info, warn};
use tokio::{
    io::unix::AsyncFd,
    signal,
    time::{interval, Instant},
};

use dma_latency_tracer_common::{
    DmaEvent, HIST_BOUNDS_NS, HIST_BUCKETS, TASK_COMM_LEN, hist_bucket,
};

// ── CLI ───────────────────────────────────────────────────────────────────────

#[derive(Debug, Parser)]
#[command(
    name    = "dma-latency-tracer",
    about   = "BPF-based DMA latency tracer for ConnectX-5 / mlx5 on PCIe Gen 3",
    version
)]
struct Opt {
    /// Reporting interval in seconds (histogram printed every N seconds).
    #[arg(short, long, default_value = "5")]
    interval: u64,

    /// Minimum latency threshold in microseconds; events below are counted
    /// but not individually printed.
    #[arg(short, long, default_value = "0")]
    min_latency_us: u64,

    /// Only report events from processes whose comm matches this substring.
    /// Useful to isolate mlx5 / RDMA traffic from background noise.
    #[arg(short, long)]
    filter_comm: Option<String>,

    /// Maximum number of individual events to print before histogram summary.
    #[arg(long, default_value = "50")]
    max_events: usize,
}

// ── Embedded BPF object ───────────────────────────────────────────────────────

// The build.rs places the compiled BPF ELF at $OUT_DIR/dma-latency-tracer-ebpf.
// include_bytes_aligned! ensures the slice is 8-byte aligned (required by aya).
static BPF_OBJECT: &[u8] = include_bytes_aligned!(
    concat!(env!("OUT_DIR"), "/dma-latency-tracer-ebpf")
);

// ── Per-process statistics ────────────────────────────────────────────────────

#[derive(Default)]
struct ProcStats {
    comm:      String,
    count:     u64,
    total_ns:  u64,
    max_ns:    u64,
    min_ns:    u64,
    histogram: [u64; HIST_BUCKETS],
}

impl ProcStats {
    fn record(&mut self, comm: &str, latency_ns: u64) {
        if self.count == 0 {
            self.min_ns = latency_ns;
            self.comm   = comm.to_string();
        }
        self.count    += 1;
        self.total_ns += latency_ns;
        if latency_ns > self.max_ns { self.max_ns = latency_ns; }
        if latency_ns < self.min_ns { self.min_ns = latency_ns; }
        self.histogram[hist_bucket(latency_ns)] += 1;
    }

    fn avg_ns(&self) -> u64 {
        if self.count == 0 { 0 } else { self.total_ns / self.count }
    }
}

// ── Entry point ───────────────────────────────────────────────────────────────

#[tokio::main]
async fn main() -> Result<()> {
    let opt = Opt::parse();
    env_logger::init();

    // ── Load and attach BPF programs ─────────────────────────────────────────
    let mut bpf = Ebpf::load(BPF_OBJECT)
        .context("failed to load BPF object; ensure kernel >= 5.8 and BTF is enabled")?;

    // Optional: pipe BPF log messages (aya-log-ebpf) to env_logger.
    if let Err(e) = EbpfLogger::init(&mut bpf) {
        warn!("aya-log not available: {e}");
    }

    // Attach kprobe on dma_map_sg entry.
    {
        let prog: &mut KProbe = bpf
            .program_mut("dma_map_sg_enter")
            .context("BPF program dma_map_sg_enter not found")?
            .try_into()
            .context("dma_map_sg_enter is not a KProbe")?;
        prog.load().context("failed to load dma_map_sg_enter")?;
        prog.attach("dma_map_sg", 0)
            .context("failed to attach kprobe to dma_map_sg; check kernel version")?;
    }

    // Attach kretprobe on dma_map_sg return.
    {
        let prog: &mut KRetProbe = bpf
            .program_mut("dma_map_sg_exit")
            .context("BPF program dma_map_sg_exit not found")?
            .try_into()
            .context("dma_map_sg_exit is not a KRetProbe")?;
        prog.load().context("failed to load dma_map_sg_exit")?;
        prog.attach("dma_map_sg", 0)
            .context("failed to attach kretprobe to dma_map_sg")?;
    }

    info!(
        "DMA latency tracer attached. Reporting every {}s. Ctrl-C to stop.",
        opt.interval
    );
    info!("Setup: ConnectX-5 (PCIe Gen4 card @ Gen3 host slot) + DAC crossover cable");
    info!("       Traffic routed through network namespaces ns0/ns1 (no loopback)");

    // ── Set up ring buffer consumer ───────────────────────────────────────────
    let ring_buf_map = bpf
        .take_map("EVENTS")
        .context("EVENTS ring buffer map not found")?;
    let ring_buf = RingBuf::try_from(ring_buf_map)
        .context("failed to create RingBuf from EVENTS map")?;

    // Wrap in an AsyncFd so Tokio can poll it without busy-waiting.
    let async_fd = AsyncFd::new(ring_buf)
        .context("failed to create AsyncFd for ring buffer")?;

    // ── Shared stats ──────────────────────────────────────────────────────────
    let mut stats: HashMap<u32, ProcStats> = HashMap::new();
    let mut total_events: u64 = 0;
    let mut printed_events: usize = 0;

    let running    = Arc::new(AtomicBool::new(true));
    let r          = running.clone();
    let mut report = interval(Duration::from_secs(opt.interval));
    let min_ns     = opt.min_latency_us * 1000;

    // ── Event loop ────────────────────────────────────────────────────────────
    loop {
        tokio::select! {
            // ── Ctrl-C ──────────────────────────────────────────────────────
            _ = signal::ctrl_c() => {
                info!("Received Ctrl-C, shutting down.");
                break;
            }

            // ── Periodic histogram report ────────────────────────────────────
            _ = report.tick() => {
                print_report(&stats, total_events, &opt);
                // Reset per-interval counters but keep totals for exit summary.
            }

            // ── Ring buffer data available ───────────────────────────────────
            guard = async_fd.readable() => {
                let mut guard = guard.context("async_fd poll error")?;
                let rb = guard.get_inner_mut();

                while let Some(item) = rb.next() {
                    // SAFETY: the BPF program writes exactly one DmaEvent per
                    // submit.  The common crate guarantees #[repr(C)] layout.
                    let event: DmaEvent = unsafe {
                        *( item.as_ptr() as *const DmaEvent )
                    };

                    let latency_ns = event.end_ns.saturating_sub(event.start_ns);
                    let comm = comm_str(&event.comm);

                    // Apply comm filter if specified.
                    if let Some(ref filter) = opt.filter_comm {
                        if !comm.contains(filter.as_str()) {
                            continue;
                        }
                    }

                    total_events += 1;
                    stats.entry(event.pid)
                         .or_default()
                         .record(&comm, latency_ns);

                    // Print individual events above threshold.
                    if latency_ns >= min_ns && printed_events < opt.max_events {
                        let dir = direction_str(event.direction);
                        info!(
                            "[cpu={:02}] pid={:6} comm={:<16} nents={:4} \
                             dir={:<12} latency={:>8.3} µs",
                            event.cpu,
                            event.pid,
                            comm,
                            event.nents,
                            dir,
                            latency_ns as f64 / 1000.0
                        );
                        printed_events += 1;
                        if printed_events == opt.max_events {
                            info!("(max_events reached, suppressing individual events; histogram continues)");
                        }
                    }
                }

                guard.clear_ready();
            }
        }
    }

    // Final summary.
    info!("─── Final summary ───");
    print_report(&stats, total_events, &opt);

    Ok(())
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/// Convert a null-terminated [u8; TASK_COMM_LEN] to a &str.
fn comm_str(comm: &[u8; TASK_COMM_LEN]) -> String {
    let end = comm.iter().position(|&b| b == 0).unwrap_or(TASK_COMM_LEN);
    String::from_utf8_lossy(&comm[..end]).into_owned()
}

/// Human-readable DMA direction.
fn direction_str(dir: u32) -> &'static str {
    match dir {
        0 => "BIDIRECTIONAL",
        1 => "TO_DEVICE",
        2 => "FROM_DEVICE",
        3 => "NONE",
        _ => "UNKNOWN",
    }
}

/// Render a bar chart row for the histogram.
fn bar(count: u64, max: u64, width: usize) -> String {
    if max == 0 { return String::new(); }
    let filled = ((count as f64 / max as f64) * width as f64).round() as usize;
    format!("{}{}", "█".repeat(filled), "░".repeat(width - filled))
}

/// Print the latency histogram and per-process table.
fn print_report(
    stats:        &HashMap<u32, ProcStats>,
    total_events: u64,
    opt:          &Opt,
) {
    if total_events == 0 {
        info!("No DMA events captured yet.");
        return;
    }

    // ── Aggregate histogram across all processes ──────────────────────────
    let mut agg_hist = [0u64; HIST_BUCKETS];
    for ps in stats.values() {
        for i in 0..HIST_BUCKETS {
            agg_hist[i] += ps.histogram[i];
        }
    }
    let hist_max = *agg_hist.iter().max().unwrap_or(&1);

    info!("═══════════════════════════════════════════════════════════════");
    info!("  dma_map_sg latency histogram  (total events: {})", total_events);
    info!("  System: ConnectX-5 PCIe Gen4 card | Gen3 host slot | DAC crossover");
    info!("───────────────────────────────────────────────────────────────");
    info!("  {:>12}   {:>8}  {:>8}  {}", "range", "count", "%", "dist");

    let labels = [
        "  0 – 500 ns",
        "500 – 1 µs  ",
        "  1 – 2 µs  ",
        "  2 – 3 µs  ",
        "  3 – 5 µs  ",
        "  5 – 7.5 µs",
        "7.5 – 10 µs ",
        " 10 – 15 µs ",
        " 15 – 20 µs ",
        " 20 – 30 µs ",
        " 30 – 50 µs ",
        " 50 – 100 µs",
        "100 – 250 µs",
        "250 – 500 µs",
        "500 µs – 1ms",
        "    > 1 ms  ",
    ];

    for (i, &count) in agg_hist.iter().enumerate() {
        let pct = if total_events > 0 {
            100.0 * count as f64 / total_events as f64
        } else {
            0.0
        };
        info!(
            "  {}  {:>8}  {:>7.2}%  |{}|",
            labels[i],
            count,
            pct,
            bar(count, hist_max, 30)
        );
    }

    // PCIe Gen3 latency interpretation note.
    let fast = agg_hist[0] + agg_hist[1] + agg_hist[2]; // < 2 µs
    let slow  = agg_hist.iter().skip(10).sum::<u64>();    // > 30 µs
    info!("───────────────────────────────────────────────────────────────");
    info!(
        "  Fast ( < 2 µs): {}  ({:.1}%)  — expected for warm IOMMU TLB",
        fast,
        100.0 * fast as f64 / total_events.max(1) as f64
    );
    info!(
        "  Slow (> 30 µs): {}  ({:.1}%)  — check IOMMU pressure / C-states",
        slow,
        100.0 * slow as f64 / total_events.max(1) as f64
    );

    // ── Per-process summary ───────────────────────────────────────────────
    if !stats.is_empty() {
        info!("───────────────────────────────────────────────────────────────");
        info!("  {:>6}  {:<16}  {:>8}  {:>10}  {:>10}  {:>10}",
              "pid", "comm", "count", "avg µs", "min µs", "max µs");
        info!("  ──────  ────────────────  ────────  ──────────  ──────────  ──────────");

        let mut sorted: Vec<(&u32, &ProcStats)> = stats.iter().collect();
        sorted.sort_by(|a, b| b.1.count.cmp(&a.1.count));

        for (pid, ps) in sorted.iter().take(20) {
            info!(
                "  {:>6}  {:<16}  {:>8}  {:>10.3}  {:>10.3}  {:>10.3}",
                pid,
                ps.comm,
                ps.count,
                ps.avg_ns() as f64 / 1000.0,
                ps.min_ns  as f64 / 1000.0,
                ps.max_ns  as f64 / 1000.0,
            );
        }
    }

    info!("═══════════════════════════════════════════════════════════════");
}

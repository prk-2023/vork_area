//! build.rs for dma-latency-tracer (userspace loader)
//!
//! This script:
//!   1. Determines the correct cargo / rustup toolchain command.
//!   2. Invokes `cargo build` targeting `bpfel-unknown-none` for the
//!      `dma-latency-tracer-ebpf` sub-crate.
//!   3. Copies the resulting ELF object into `OUT_DIR` where the userspace
//!      `main.rs` embeds it via `include_bytes_aligned!`.
//!
//! Why build.rs instead of xtask?
//! --------------------------------
//! xtask is a developer-ergonomics pattern but adds a mandatory two-step
//! build (cargo xtask build-ebpf && cargo build).  Using build.rs makes
//! `cargo build` alone sufficient: the eBPF compilation is a dependency of
//! the host binary compilation, runs automatically, and benefits from
//! Cargo's incremental rebuild logic.

use std::{
    env,
    path::{Path, PathBuf},
    process::Command,
};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    // ── 0. Basic cargo metadata ───────────────────────────────────────────────
    let out_dir     = PathBuf::from(env::var_os("OUT_DIR").unwrap());
    let manifest_dir = PathBuf::from(env::var_os("CARGO_MANIFEST_DIR").unwrap());

    // The workspace root is one level above the userspace crate.
    let workspace_root = manifest_dir
        .parent()
        .expect("expected workspace root to be parent of crate directory")
        .to_path_buf();

    // Path to the eBPF sub-crate.
    let ebpf_crate_dir = workspace_root.join("dma-latency-tracer-ebpf");

    // Trigger a rebuild whenever the eBPF source or the common types change.
    println!("cargo::rerun-if-changed={}", ebpf_crate_dir.join("src/main.rs").display());
    println!("cargo::rerun-if-changed={}", workspace_root.join("dma-latency-tracer-common/src/lib.rs").display());
    println!("cargo::rerun-if-changed=build.rs");

    // ── 1. Determine profile: mirror the host build (debug vs release) ────────
    let profile = env::var("PROFILE").unwrap_or_else(|_| "debug".to_string());
    let release = profile == "release";

    // ── 2. Locate the cargo binary ────────────────────────────────────────────
    // Use the same cargo that is building us so version / toolchain match.
    let cargo = env::var_os("CARGO")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("cargo"));

    // ── 3. Invoke cargo to build the eBPF crate ───────────────────────────────
    //
    // Flags:
    //   --target bpfel-unknown-none   little-endian BPF
    //   -Z build-std=core             cross-compile core (nightly only)
    //   --manifest-path …             point at the eBPF sub-crate
    //
    // The eBPF crate's own .cargo/config.toml sets:
    //   rustflags = ["-C debuginfo=2", "-C link-arg=--btf"]
    // which causes bpf-linker to emit BTF debug info required for CO-RE.

    let mut cmd = Command::new(&cargo);
    cmd.current_dir(&workspace_root)
        .env("CARGO_ENCODED_RUSTFLAGS", "") // avoid inheriting host RUSTFLAGS
        .arg("+nightly")                    // force nightly for -Z build-std
        .arg("build")
        .arg("--package")
        .arg("dma-latency-tracer-ebpf")
        .arg("--target")
        .arg("bpfel-unknown-none")
        .arg("-Z")
        .arg("build-std=core");

    if release {
        cmd.arg("--release");
    }

    // Pass through RUST_LOG so any diagnostic output from the child cargo is
    // visible when the user sets RUST_LOG=cargo=debug.
    if let Ok(v) = env::var("RUST_LOG") {
        cmd.env("RUST_LOG", v);
    }

    let status = cmd
        .status()
        .map_err(|e| format!("failed to execute cargo: {e}"))?;

    if !status.success() {
        return Err(format!(
            "cargo build for dma-latency-tracer-ebpf failed with status: {status}"
        )
        .into());
    }

    // ── 4. Locate the compiled BPF object ────────────────────────────────────
    //
    // Cargo places the output at:
    //   <workspace>/target/bpfel-unknown-none/<profile>/dma-latency-tracer-ebpf
    //
    // Note: the binary name is derived from [[bin]] name in Cargo.toml, which
    // may use hyphens on disk (cargo normalises them).

    let bpf_profile = if release { "release" } else { "debug" };
    let bpf_obj = workspace_root
        .join("target")
        .join("bpfel-unknown-none")
        .join(bpf_profile)
        .join("dma-latency-tracer-ebpf");

    if !bpf_obj.exists() {
        return Err(format!(
            "expected BPF object at {} but it was not found",
            bpf_obj.display()
        )
        .into());
    }

    // ── 5. Copy object to OUT_DIR ─────────────────────────────────────────────
    //
    // The userspace binary embeds it with:
    //   include_bytes_aligned!(concat!(env!("OUT_DIR"), "/dma-latency-tracer-ebpf"))
    //
    // We use a fixed name so the include path never changes across rebuilds.

    let dest = out_dir.join("dma-latency-tracer-ebpf");
    std::fs::copy(&bpf_obj, &dest).map_err(|e| {
        format!(
            "failed to copy {} → {}: {e}",
            bpf_obj.display(),
            dest.display()
        )
    })?;

    println!(
        "cargo::warning=BPF object copied to {}",
        dest.display()
    );

    Ok(())
}

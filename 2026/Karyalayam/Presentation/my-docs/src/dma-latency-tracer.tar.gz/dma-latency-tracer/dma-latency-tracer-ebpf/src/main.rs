//! eBPF DMA latency tracer for Mellanox ConnectX-5 on a PCIe Gen 3 host.
//!
//! Instruments:
//!   kprobe  on `dma_map_sg`   → records entry timestamp + sg nents
//!   kretprobe on `dma_map_sg` → computes latency, emits DmaEvent to ring buf
//!
//! Architecture note
//! -----------------
//! `dma_map_sg(struct device *dev, struct scatterlist *sg, int nents,
//!              enum dma_data_direction dir)`
//!
//! On the ConnectX-5 + mlx5 driver path the call chain is:
//!   mlx5_ib_post_send / mlx5e_sq_xmit
//!     └─ mlx5_core_create_qp / ib_dma_map_sg
//!           └─ dma_map_sg   ← our probe site
//!
//! We use a BPF_MAP_TYPE_HASH keyed on (cpu, pid) to stash the entry
//! timestamp between kprobe and kretprobe.  Per-CPU hash avoids lock
//! contention on heavily loaded NICs.
//!
//! All events are pushed into a BPF_MAP_TYPE_RINGBUF for low-overhead
//! delivery to userspace.

#![no_std]
#![no_main]

use aya_ebpf::{
    helpers::{bpf_get_current_comm, bpf_get_current_pid_tgid, bpf_ktime_get_ns, bpf_get_smp_processor_id},
    macros::{kprobe, kretprobe, map},
    maps::{HashMap, RingBuf},
    programs::{ProbeContext, RetProbeContext},
};
use aya_log_ebpf::warn;
use dma_latency_tracer_common::{DmaEvent, TASK_COMM_LEN};

// ── Maps ──────────────────────────────────────────────────────────────────────

/// Per-(cpu, pid) entry state: [start_ns, nents, direction].
/// Key encodes cpu (high 32 bits) | pid (low 32 bits) to stay lock-free.
/// Max entries: 4096 covers up to 4096 concurrent in-flight dma_map_sg calls.
#[map]
static START_MAP: HashMap<u64, EntryData> = HashMap::with_max_entries(4096, 0);

/// Ring buffer for DmaEvent delivery to userspace.
/// 4 MiB gives ~52 000 events before wrap under sustained 100 GbE load.
#[map]
static EVENTS: RingBuf = RingBuf::with_byte_size(4 * 1024 * 1024, 0);

// ── Internal entry state (NOT exported to userspace) ─────────────────────────

/// Stored in START_MAP between kprobe entry and kretprobe return.
#[repr(C)]
#[derive(Clone, Copy)]
struct EntryData {
    start_ns:  u64,
    nents:     u32,
    direction: u32,
    comm:      [u8; TASK_COMM_LEN],
}

// ── kprobe: dma_map_sg entry ──────────────────────────────────────────────────

/// Signature (kernel):
///   int dma_map_sg(struct device *dev, struct scatterlist *sg,
///                  int nents, enum dma_data_direction direction)
///
/// arg(0) = dev       (*struct device)
/// arg(1) = sg        (*struct scatterlist)
/// arg(2) = nents     (int)
/// arg(3) = direction (int, enum dma_data_direction)
#[kprobe]
pub fn dma_map_sg_enter(ctx: ProbeContext) -> u32 {
    match try_dma_map_sg_enter(&ctx) {
        Ok(()) => 0,
        Err(e) => {
            warn!(&ctx, "dma_map_sg_enter error: {}", e);
            0 // never return non-zero from kprobe
        }
    }
}

#[inline(always)]
fn try_dma_map_sg_enter(ctx: &ProbeContext) -> Result<(), i64> {
    // arg(2) = nents (int), arg(3) = direction (enum)
    let nents: i32     = unsafe { ctx.arg(2).ok_or(1i64)? };
    let direction: i32 = unsafe { ctx.arg(3).ok_or(1i64)? };

    let pid_tgid = bpf_get_current_pid_tgid();
    let pid      = (pid_tgid & 0xFFFF_FFFF) as u32;
    let cpu      = bpf_get_smp_processor_id();

    // Key = cpu (high 32) | pid (low 32).  Unique per CPU × task.
    let key: u64 = ((cpu as u64) << 32) | (pid as u64);

    let mut comm = [0u8; TASK_COMM_LEN];
    // SAFETY: bpf_get_current_comm writes into the provided buffer.
    unsafe { bpf_get_current_comm(&mut comm) }.map_err(|_| 2i64)?;

    let entry = EntryData {
        start_ns:  unsafe { bpf_ktime_get_ns() },
        nents:     nents.unsigned_abs(),
        direction: direction.unsigned_abs(),
        comm,
    };

    START_MAP.insert(&key, &entry, 0).map_err(|e| e as i64)?;
    Ok(())
}

// ── kretprobe: dma_map_sg return ─────────────────────────────────────────────

#[kretprobe]
pub fn dma_map_sg_exit(ctx: RetProbeContext) -> u32 {
    match try_dma_map_sg_exit(&ctx) {
        Ok(()) => 0,
        Err(e) => {
            warn!(&ctx, "dma_map_sg_exit error: {}", e);
            0
        }
    }
}

#[inline(always)]
fn try_dma_map_sg_exit(ctx: &RetProbeContext) -> Result<(), i64> {
    let end_ns   = unsafe { bpf_ktime_get_ns() };
    let pid_tgid = bpf_get_current_pid_tgid();
    let pid      = (pid_tgid & 0xFFFF_FFFF) as u32;
    let cpu      = bpf_get_smp_processor_id();

    let key: u64 = ((cpu as u64) << 32) | (pid as u64);

    // Look up the entry data stored at kprobe entry.
    let entry = START_MAP.get(&key).ok_or(3i64)?;

    // Always clean up to avoid stale entries accumulating.
    let _ = START_MAP.remove(&key);

    // If the DMA mapping failed (ret == 0) the hardware never performed DMA;
    // skip the event – failed mappings are not latency signals.
    let ret: i64 = ctx.ret();
    if ret == 0 {
        return Ok(());
    }

    // Reserve space in the ring buffer for one DmaEvent.
    // reserve() returns None if the ring is full; silently drop the event
    // rather than blocking the kernel path.
    let mut buf = EVENTS
        .reserve::<DmaEvent>(0)
        .ok_or(4i64)?;

    let event = buf.as_mut_ptr();
    unsafe {
        (*event).start_ns  = entry.start_ns;
        (*event).end_ns    = end_ns;
        (*event).nents     = entry.nents;
        (*event).pid       = pid;
        (*event).comm      = entry.comm;
        (*event).cpu       = cpu;
        (*event).direction = entry.direction;
    }

    buf.submit(0);
    Ok(())
}

// ── Panic handler ─────────────────────────────────────────────────────────────

#[cfg(not(test))]
#[panic_handler]
fn panic(_info: &core::panic::PanicInfo) -> ! {
    loop {}
}

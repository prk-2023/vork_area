// build.rs for dma-latency-tracer-ebpf
//
// This crate is compiled by the parent userspace build.rs via a child cargo
// invocation targeting bpfel-unknown-none.  This build.rs runs inside that
// child process and simply verifies that bpf-linker is installed.

fn main() {
    // Only meaningful when being compiled for the BPF target.
    // The parent build.rs for the userspace crate handles the heavy lifting.
    if std::env::var("CARGO_CFG_TARGET_ARCH").as_deref() == Ok("bpf") {
        // Verify bpf-linker is present; give a clear error if not.
        which::which("bpf-linker").unwrap_or_else(|_| {
            panic!(
                "\n\nbpf-linker not found on PATH.\n\
                 Install it with:\n\
                 \n\
                 \tcargo install bpf-linker\n\
                 \n\
                 On systems where the host LLVM does not match the required\n\
                 version, follow the bpf-linker README for external LLVM:\n\
                 https://github.com/aya-rs/bpf-linker\n"
            );
        });
    }
    println!("cargo::rerun-if-changed=build.rs");
    println!("cargo::rerun-if-changed=src/main.rs");
}

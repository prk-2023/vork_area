//! Shared types between the eBPF program and the userspace loader.
//!
//! This crate is compiled for TWO targets:
//!   1. `bpfel-unknown-none`  – no_std, from the eBPF crate
//!   2. host triple           – std, from the userspace loader
//!
//! Keep everything `#[repr(C)]` so the memory layout is identical on both
//! sides.  Do NOT add heap-allocated types here.
#![no_std]

/// Maximum length of the `comm` (command name) field copied from the kernel.
/// The kernel limits task_comm_len to 16 bytes including the null terminator.
pub const TASK_COMM_LEN: usize = 16;

// ── ConnectX-5 / PCIe topology constants ─────────────────────────────────────
//
// Physical setup:
//   • Motherboard: PCIe Gen 3.0 x16 slot  (max 16 GB/s bidirectional)
//   • Card:        Mellanox ConnectX-5 100GbE  (PCIe Gen 4 capable,
//                  operates at Gen 3 speed when host only supports Gen 3)
//   • Cabling:     Direct-Attach Copper (DAC) crossover cable between the
//                  two ports (Port 0 ↔ Port 1)
//   • Namespaces:  Each port bound to a separate Linux network namespace to
//                  force traffic through the physical medium rather than
//                  loopback.
//
// DMA operations we instrument:
//   dma_map_sg   – maps a scatter-gather list for device DMA.  Called by the
//                  mlx5 driver every time it programmes the HCA's DMA engine.
//   dma_unmap_sg – releases the mapping after the HCA signals completion.
//
// Latency budget notes (PCIe Gen 3 x16):
//   • IOMMU translation (if enabled) adds ~100–500 ns per dma_map_sg call.
//   • dma_map_sg itself is typically < 2 µs on a warm IOMMU TLB.
//   • Values > 10 µs suggest IOMMU TLB pressure or CPU frequency scaling.

/// A single DMA latency event recorded by the eBPF kprobe/kretprobe pair.
///
/// Populated in the BPF ring buffer and consumed by the userspace reporter.
#[repr(C)]
#[derive(Clone, Copy)]
pub struct DmaEvent {
    /// Kernel monotonic timestamp (ns) when `dma_map_sg` was entered.
    pub start_ns: u64,

    /// Kernel monotonic timestamp (ns) when `dma_map_sg` returned.
    /// Latency = `end_ns - start_ns`.
    pub end_ns: u64,

    /// Number of scatter-gather list entries passed to `dma_map_sg`.
    /// Correlates DMA latency with transfer size.
    pub nents: u32,

    /// PID of the process that called `dma_map_sg` (task context).
    pub pid: u32,

    /// Null-terminated process name (comm), max 16 bytes.
    pub comm: [u8; TASK_COMM_LEN],

    /// CPU number on which the call was observed.
    pub cpu: u32,

    /// DMA direction: DMA_TO_DEVICE=1, DMA_FROM_DEVICE=2, DMA_BIDIRECTIONAL=0
    pub direction: u32,
}

// Safety: DmaEvent is POD – no pointers, no padding-sensitive fields.
// Both sides use the same #[repr(C)] layout.
unsafe impl Send for DmaEvent {}
unsafe impl Sync for DmaEvent {}

// ── Histogram bucket boundaries ───────────────────────────────────────────────
//
// Latency histogram for display.  Buckets are in nanoseconds.
// Chosen to give good resolution across the expected 0.5 µs – 50 µs range
// for ConnectX-5 DMA on a Gen 3 host.

pub const HIST_BUCKETS: usize = 16;

/// Bucket upper bounds in nanoseconds.  The last bucket is "overflow" (∞).
pub const HIST_BOUNDS_NS: [u64; HIST_BUCKETS] = [
    500,        //  0:   0 –   500 ns
    1_000,      //  1: 500 –   1 µs
    2_000,      //  2:   1 –   2 µs
    3_000,      //  3:   2 –   3 µs
    5_000,      //  4:   3 –   5 µs
    7_500,      //  5:   5 – 7.5 µs
    10_000,     //  6: 7.5 –  10 µs
    15_000,     //  7:  10 –  15 µs
    20_000,     //  8:  15 –  20 µs
    30_000,     //  9:  20 –  30 µs
    50_000,     // 10:  30 –  50 µs
    100_000,    // 11:  50 – 100 µs
    250_000,    // 12: 100 – 250 µs
    500_000,    // 13: 250 – 500 µs
    1_000_000,  // 14: 500 µs –  1 ms
    u64::MAX,   // 15:   > 1 ms  (overflow / anomaly)
];

/// Returns the histogram bucket index for a given latency in nanoseconds.
#[inline(always)]
pub fn hist_bucket(latency_ns: u64) -> usize {
    for (i, &bound) in HIST_BOUNDS_NS.iter().enumerate() {
        if latency_ns <= bound {
            return i;
        }
    }
    HIST_BUCKETS - 1
}

#!/usr/bin/env bash
# generate_traffic.sh
#
# Generate NIC-to-NIC traffic across the DAC cable so the DMA latency
# tracer has events to report.
#
# Usage:
#   bash generate_traffic.sh          # default: iperf3 TCP, 30 s, 8 streams
#   bash generate_traffic.sh udp      # UDP mode (lower CPU, higher PPS)
#   bash generate_traffic.sh ping     # simple ping flood
#
# The script expects ns1 (10.0.0.1) and ns2 (10.0.0.10) to be set up
# by setup.sh already.

set -euo pipefail

MODE="${1:-tcp}"
DURATION=30
PARALLEL=8
SERVER_NS=ns1
SERVER_IP=10.0.0.1
CLIENT_NS=ns2

echo "==> Traffic generator for DMA latency tracer"
echo "    Mode     : $MODE"
echo "    Duration : ${DURATION}s"
echo "    Server   : $SERVER_NS ($SERVER_IP)"
echo "    Client   : $CLIENT_NS"
echo ""

case "$MODE" in
tcp)
    echo "==> Starting iperf3 TCP server in $SERVER_NS…"
    ip netns exec "$SERVER_NS" iperf3 -s -D --logfile /tmp/iperf3-server.log
    sleep 1
    echo "==> Running iperf3 TCP client from $CLIENT_NS (${PARALLEL} streams)…"
    ip netns exec "$CLIENT_NS" iperf3 \
        -c "$SERVER_IP" \
        -t "$DURATION" \
        -P "$PARALLEL" \
        --bidir                # bidirectional to stress both TX and RX DMA paths
    pkill -f "iperf3 -s" || true
    ;;

udp)
    echo "==> Starting iperf3 UDP server in $SERVER_NS…"
    ip netns exec "$SERVER_NS" iperf3 -s -D --logfile /tmp/iperf3-server.log
    sleep 1
    echo "==> Running iperf3 UDP client from $CLIENT_NS (target 20 Gbps)…"
    ip netns exec "$CLIENT_NS" iperf3 \
        -c "$SERVER_IP" \
        -u \
        -b 20G \
        -t "$DURATION" \
        -P "$PARALLEL" \
        -l 9000              # jumbo frames if MTU allows
    pkill -f "iperf3 -s" || true
    ;;

ping)
    echo "==> Running ping flood from $CLIENT_NS to $SERVER_IP…"
    ip netns exec "$CLIENT_NS" ping -f -c 100000 "$SERVER_IP"
    ;;

*)
    echo "Unknown mode: $MODE.  Use: tcp | udp | ping"
    exit 1
    ;;
esac

echo ""
echo "==> Traffic generation complete."

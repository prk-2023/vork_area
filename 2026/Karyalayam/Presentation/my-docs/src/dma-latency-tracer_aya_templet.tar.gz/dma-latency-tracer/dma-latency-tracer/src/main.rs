// dma-latency-tracer/src/main.rs
//
// Userspace loader and reporter for the DMA-latency eBPF program.
//
// What it does
// ────────────
// 1. Loads the eBPF ELF (compiled by build.rs into OUT_DIR).
// 2. Attaches kprobes to the three probe sites in the kernel's
//    DMA-mapping API that cover the mlx5 driver on the Mellanox
//    ConnectX-5 card.
// 3. Polls the BPF ring buffer for completed DmaLatencyEvent records.
// 4. Maintains rolling statistics and prints a live dashboard to the
//    terminal every second.
//
// Network topology (for reference – the eBPF code is topology-agnostic)
// ──────────────────────────────────────────────────────────────────────
//   ns1 (10.0.0.1/24)  ←──DAC cable──→  ns2 (10.0.0.10/24)
//   Port 0                               Port 1
//   Both ports belong to the Mellanox ConnectX-5 SmartNIC.
//   PCIe 3.0 x16 host interface (≈ 125 GB/s theoretical host bandwidth).
//
// Running
// ───────
//   sudo ./dma-latency-tracer [--interval <secs>] [--histogram]
//
// Privileges: CAP_BPF + CAP_SYS_ADMIN (or run as root).

use std::{
    collections::BTreeMap,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::{Duration, Instant},
};

use anyhow::{Context, Result};
use aya::{
    Bpf,
    maps::RingBuf,
    programs::{KProbe, KRetProbe},
};
use aya_log::BpfLogger;
use clap::Parser;
use common::{DmaDirection, DmaLatencyEvent, DmaStats};
use crossterm::{
    cursor,
    execute,
    style::{self, Color, Stylize},
    terminal::{self, ClearType},
};
use log::{info, warn};
use tokio::signal;

// ── CLI ───────────────────────────────────────────────────────────────────────

#[derive(Parser, Debug)]
#[command(
    name    = "dma-latency-tracer",
    about   = "Per-DMA-transfer latency tracer for Mellanox ConnectX-5 / mlx5",
    version = "0.1.0",
)]
struct Cli {
    /// Reporting interval in seconds.
    #[arg(short, long, default_value_t = 1)]
    interval: u64,

    /// Print a latency histogram in addition to the summary table.
    #[arg(long)]
    histogram: bool,

    /// Number of histogram buckets (log2 ns scale).
    #[arg(long, default_value_t = 20)]
    buckets: usize,

    /// Only report DMA operations ≥ this many nanoseconds.
    #[arg(long, default_value_t = 0)]
    min_ns: u64,
}

// ── eBPF ELF (embedded at compile time by build.rs) ──────────────────────────

/// The eBPF ELF is embedded as a byte slice so the binary is fully
/// self-contained (no separate .o file needed at runtime).
static BPF_ELF: &[u8] = include_bytes!(env!("BPF_ELF"));

// ── Histogram helpers ─────────────────────────────────────────────────────────

/// Logarithmic histogram over latency values (base-2 bucket boundaries).
struct Histogram {
    buckets: Vec<u64>,   // counts per bucket
    boundaries: Vec<u64>, // upper bound (ns) of each bucket
}

impl Histogram {
    fn new(n_buckets: usize) -> Self {
        // Buckets span 1 ns … 2^n_buckets ns on a log2 scale.
        let boundaries: Vec<u64> = (0..n_buckets)
            .map(|i| 1u64 << i)
            .collect();
        Self {
            buckets: vec![0u64; n_buckets],
            boundaries,
        }
    }

    fn record(&mut self, latency_ns: u64) {
        let idx = self
            .boundaries
            .partition_point(|&b| latency_ns > b)
            .min(self.buckets.len() - 1);
        self.buckets[idx] += 1;
    }

    fn print(&self) {
        let max_count = *self.buckets.iter().max().unwrap_or(&1).max(&1);
        let bar_width  = 40usize;

        println!();
        println!("  ┌─ Latency Histogram (log₂ ns) ─────────────────────────────────┐");
        for (i, (&count, &upper_ns)) in
            self.buckets.iter().zip(self.boundaries.iter()).enumerate()
        {
            if count == 0 && i > 0 && self.buckets[i - 1] == 0 { continue; }

            let lower_ns = if i == 0 { 0 } else { self.boundaries[i - 1] };
            let filled   = (count as usize * bar_width) / max_count as usize;
            let bar: String = "█".repeat(filled) + &" ".repeat(bar_width - filled);
            println!(
                "  │ {:>6}–{:<6} ns │ {} {:>7} │",
                lower_ns, upper_ns, bar, count
            );
        }
        println!("  └───────────────────────────────────────────────────────────────┘");
    }

    fn reset(&mut self) {
        self.buckets.iter_mut().for_each(|c| *c = 0);
    }
}

// ── Main ──────────────────────────────────────────────────────────────────────

#[tokio::main]
async fn main() -> Result<()> {
    env_logger::Builder::from_env(
        env_logger::Env::default().default_filter_or("info"),
    )
    .init();

    let cli = Cli::parse();

    // ── 1. Load the eBPF program ──────────────────────────────────────────
    info!("Loading eBPF program ({} bytes)…", BPF_ELF.len());
    let mut bpf = Bpf::load(BPF_ELF)
        .context("Failed to load eBPF ELF – are you running as root?")?;

    // Forward eBPF log messages to the host logger (debug builds of the
    // eBPF crate emit log records via aya-log-ebpf).
    if let Err(e) = BpfLogger::init(&mut bpf) {
        warn!("BPF logger init failed (non-fatal): {e}");
    }

    // ── 2. Attach probes ─────────────────────────────────────────────────
    //
    // We attach to three sites in the kernel DMA API that mlx5 uses:
    //
    //   dma_map_page           – entry: record start time + metadata
    //   dma_map_page           – return: record bus (DMA) address
    //   dma_unmap_page_attrs   – entry: compute latency, emit event
    //
    // Note: on kernels that inline dma_map_page into dma_map_single or
    // other wrappers the kprobe may not fire.  In that case add probes
    // for the architecture-specific implementation:
    //   e.g.  iommu_dma_map_page  or  swiotlb_map_page

    attach_kprobe(&mut bpf, "dma_map_page_enter",    "dma_map_page",          0)?;
    attach_kretprobe(&mut bpf, "dma_map_page_exit",  "dma_map_page"            )?;
    attach_kprobe(&mut bpf, "dma_unmap_page_enter",  "dma_unmap_page_attrs",   0)?;

    info!("Probes attached.  Tracing DMA transfers on ConnectX-5…");
    info!("  Press Ctrl-C to stop.");

    // ── 3. Open the ring buffer map ───────────────────────────────────────
    let ring_buf_map = bpf
        .map_mut("EVENTS")
        .context("EVENTS ring buffer map not found")?;
    let mut ring = RingBuf::try_from(ring_buf_map)
        .context("Failed to create RingBuf handle")?;

    // ── 4. Event loop ─────────────────────────────────────────────────────
    let running  = Arc::new(AtomicBool::new(true));
    let r2       = running.clone();
    tokio::spawn(async move {
        signal::ctrl_c().await.ok();
        r2.store(false, Ordering::Relaxed);
    });

    let interval     = Duration::from_secs(cli.interval);
    let mut deadline = Instant::now() + interval;

    // Per-window accumulators
    let mut stats_tx = DmaStats::default();
    let mut stats_rx = DmaStats::default();
    let mut hist     = Histogram::new(cli.buckets);

    let window_start = Instant::now();
    let mut last_report = window_start;

    // Enable raw mode for the live dashboard
    let mut stdout = std::io::stdout();
    terminal::enable_raw_mode().ok();
    execute!(stdout, cursor::Hide, terminal::Clear(ClearType::All)).ok();

    while running.load(Ordering::Relaxed) {
        // Non-blocking drain of the ring buffer
        drain_ring(&mut ring, &cli, &mut stats_tx, &mut stats_rx, &mut hist)?;

        // Report on interval boundary
        if Instant::now() >= deadline {
            let elapsed = last_report.elapsed();
            stats_tx.window_ns = elapsed.as_nanos() as u64;
            stats_rx.window_ns = elapsed.as_nanos() as u64;

            print_dashboard(&mut stdout, &stats_tx, &stats_rx, &hist, cli.histogram)?;

            // Reset per-window state
            stats_tx = DmaStats { min_ns: u64::MAX, ..Default::default() };
            stats_rx = DmaStats { min_ns: u64::MAX, ..Default::default() };
            hist.reset();
            last_report = Instant::now();
            deadline    = last_report + interval;
        }

        // Yield briefly so Tokio can run other tasks (signal handler etc.)
        tokio::time::sleep(Duration::from_micros(100)).await;
    }

    // Cleanup
    terminal::disable_raw_mode().ok();
    execute!(stdout, cursor::Show).ok();
    println!("\nTracing stopped.");
    Ok(())
}

// ── Probe attachment helpers ──────────────────────────────────────────────────

fn attach_kprobe(
    bpf:      &mut Bpf,
    prog_name: &str,
    fn_name:   &str,
    offset:    u64,
) -> Result<()> {
    let prog: &mut KProbe = bpf
        .program_mut(prog_name)
        .with_context(|| format!("Program '{prog_name}' not found in ELF"))?
        .try_into()?;
    prog.load()?;
    prog.attach(fn_name, offset)
        .with_context(|| format!("kprobe attach failed for '{fn_name}'"  ))?;
    info!("  kprobe attached: {} → {}", prog_name, fn_name);
    Ok(())
}

fn attach_kretprobe(
    bpf:      &mut Bpf,
    prog_name: &str,
    fn_name:   &str,
) -> Result<()> {
    let prog: &mut KRetProbe = bpf
        .program_mut(prog_name)
        .with_context(|| format!("Program '{prog_name}' not found in ELF"))?
        .try_into()?;
    prog.load()?;
    prog.attach(fn_name, 0)
        .with_context(|| format!("kretprobe attach failed for '{fn_name}'" ))?;
    info!("  kretprobe attached: {} → {}", prog_name, fn_name);
    Ok(())
}

// ── Ring buffer drain ─────────────────────────────────────────────────────────

fn drain_ring(
    ring:     &mut RingBuf<&mut aya::maps::MapData>,
    cli:      &Cli,
    stats_tx: &mut DmaStats,
    stats_rx: &mut DmaStats,
    hist:     &mut Histogram,
) -> Result<()> {
    // next() is non-blocking; returns None when the buffer is empty.
    while let Some(item) = ring.next() {
        // Safety: the eBPF program writes exactly one DmaLatencyEvent per
        // ring buffer reservation.  The size is verified at the type level
        // (aya uses the generic parameter to set the reservation size).
        let event: DmaLatencyEvent =
            unsafe { std::ptr::read_unaligned(item.as_ptr() as *const _) };

        if event.latency_ns < cli.min_ns {
            continue;
        }

        hist.record(event.latency_ns);

        let stats = if event.direction == DmaDirection::FromDevice as u8 {
            stats_rx
        } else {
            stats_tx
        };

        stats.count       += 1;
        stats.sum_ns      += event.latency_ns;
        stats.sum_bytes   += event.transfer_bytes;
        if stats.min_ns == 0 || event.latency_ns < stats.min_ns {
            stats.min_ns = event.latency_ns;
        }
        if event.latency_ns > stats.max_ns {
            stats.max_ns = event.latency_ns;
        }
    }
    Ok(())
}

// ── Dashboard renderer ────────────────────────────────────────────────────────

fn print_dashboard(
    stdout:      &mut std::io::Stdout,
    stats_tx:    &DmaStats,
    stats_rx:    &DmaStats,
    hist:        &Histogram,
    show_hist:   bool,
) -> Result<()> {
    use std::io::Write;

    execute!(
        stdout,
        cursor::MoveTo(0, 0),
        terminal::Clear(ClearType::All),
    )?;

    // Header
    println!(
        "{}",
        " ╔══ DMA Latency Tracer — Mellanox ConnectX-5 (mlx5) — PCIe 3.0 ══╗ "
            .with(Color::Cyan)
            .bold()
    );

    let ts = chrono_now();
    println!(" Timestamp : {ts}");
    println!(" Interface : ConnectX-5 25GbE  │  Topology: ns1 ←DAC→ ns2");
    println!(" ──────────────────────────────────────────────────────────");

    print_dir_stats("TX (to-device  / host→NIC)", stats_tx);
    print_dir_stats("RX (from-device / NIC→host)", stats_rx);

    // Combined throughput
    let combined_bps = stats_tx.throughput_bps() + stats_rx.throughput_bps();
    let combined_gbps = combined_bps as f64 / 125_000_000.0;
    println!();
    println!(
        " Combined DMA throughput : {:.3} Gbps  ({} B transferred)",
        combined_gbps,
        fmt_bytes(stats_tx.sum_bytes + stats_rx.sum_bytes),
    );
    println!(
        " PCIe 3.0 x16 headroom  : {:.1}%  (theoretical max ~125 GB/s)",
        (combined_bps as f64 / (125e9)) * 100.0
    );

    if show_hist {
        hist.print();
    }

    println!();
    println!(" Press Ctrl-C to exit.");

    stdout.flush()?;
    Ok(())
}

fn print_dir_stats(label: &str, s: &DmaStats) {
    if s.count == 0 {
        println!(" {label}");
        println!("   No samples in this window.");
        return;
    }
    println!(
        " {}",
        label.with(Color::Yellow).bold()
    );
    println!(
        "   Samples : {:>10}    Bytes   : {}",
        s.count,
        fmt_bytes(s.sum_bytes)
    );
    println!(
        "   Avg lat : {:>8} ns   Min lat : {} ns",
        s.avg_ns(),
        s.min_ns
    );
    println!(
        "   Max lat : {:>8} ns   Tput    : {:.3} Gbps",
        s.max_ns,
        s.throughput_gbps()
    );
}

// ── Tiny helpers ──────────────────────────────────────────────────────────────

fn fmt_bytes(b: u64) -> String {
    const UNITS: &[&str] = &["B", "KiB", "MiB", "GiB", "TiB"];
    let mut v = b as f64;
    let mut i = 0;
    while v >= 1024.0 && i < UNITS.len() - 1 {
        v /= 1024.0;
        i += 1;
    }
    format!("{:.2} {}", v, UNITS[i])
}

fn chrono_now() -> String {
    // Use CLOCK_REALTIME via libc to avoid pulling in chrono.
    use std::time::{SystemTime, UNIX_EPOCH};
    let secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    // Emit a simple ISO-8601-ish string (UTC epoch seconds)
    format!("{secs} s (Unix epoch UTC)")
}

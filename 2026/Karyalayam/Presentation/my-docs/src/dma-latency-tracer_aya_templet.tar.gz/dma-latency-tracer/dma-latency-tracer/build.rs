// dma-latency-tracer/build.rs
//
// This build script cross-compiles the eBPF crate
// (dma-latency-tracer-ebpf) for the `bpfel-unknown-none` target and
// embeds the resulting ELF bytes as a byte array via the OUT_DIR so
// the userspace binary can load it at runtime without needing the ELF
// file on disk.
//
// Aya 0.13 convention: compile the eBPF crate here in build.rs.
// (Older Aya used xtask; 0.13+ prefers build.rs for simpler projects.)
//
// Build-time dependencies:
//   • cargo (on PATH)
//   • rustup target add bpfel-unknown-none
//   • LLVM / clang (for linking, provided by the rust-lld in the
//     bpf toolchain)

use std::{
    env,
    fs,
    path::{Path, PathBuf},
    process::Command,
};

fn main() {
    // Tell Cargo to re-run this script only when the eBPF source changes.
    println!("cargo:rerun-if-changed=../dma-latency-tracer-ebpf/src/");
    println!("cargo:rerun-if-changed=../common/src/");

    let out_dir  = PathBuf::from(env::var("OUT_DIR").unwrap());
    let manifest = PathBuf::from(env::var("CARGO_MANIFEST_DIR").unwrap());
    let ebpf_dir = manifest.parent().unwrap().join("dma-latency-tracer-ebpf");

    // Determine build profile to pass through (dev vs release).
    let profile = env::var("PROFILE").unwrap();
    let release  = profile == "release";

    // ── Cross-compile the eBPF crate ─────────────────────────────────────
    let mut cmd = Command::new("cargo");
    cmd.args([
        "build",
        "--package", "dma-latency-tracer-ebpf",
        "--target",  "bpfel-unknown-none",
        "-Z", "build-std=core",   // required for no_std eBPF target
    ]);
    if release {
        cmd.arg("--release");
    }
    // Point cargo at the workspace root so it can resolve shared members.
    cmd.current_dir(manifest.parent().unwrap());
    // Disable RUSTFLAGS that might contain host-only flags.
    cmd.env_remove("RUSTFLAGS");
    // Use nightly features needed for build-std.
    cmd.env("CARGO_UNSTABLE_BUILD_STD", "true");

    let status = cmd.status().expect("failed to invoke cargo for eBPF crate");
    if !status.success() {
        panic!("eBPF crate compilation failed");
    }

    // ── Locate the compiled ELF ───────────────────────────────────────────
    // cargo writes to <workspace>/target/bpfel-unknown-none/<profile>/
    let target_dir = find_target_dir(&manifest);
    let sub_dir    = if release { "release" } else { "debug" };
    let elf_src    = target_dir
        .join("bpfel-unknown-none")
        .join(sub_dir)
        .join("dma-latency-tracer-ebpf");

    if !elf_src.exists() {
        panic!(
            "Expected eBPF ELF at {:?} but it was not found.\n\
             Make sure `bpfel-unknown-none` target is installed:\n\
             \  rustup target add bpfel-unknown-none",
            elf_src
        );
    }

    // ── Copy ELF to OUT_DIR for embedding ────────────────────────────────
    let elf_dst = out_dir.join("dma-latency-tracer-ebpf.elf");
    fs::copy(&elf_src, &elf_dst)
        .expect("failed to copy eBPF ELF to OUT_DIR");

    // The ELF path is exposed as a compile-time env var used in main.rs:
    //   include_bytes!(env!("BPF_ELF"))
    println!("cargo:rustc-env=BPF_ELF={}", elf_dst.display());
}

/// Walk up from the manifest directory to find the workspace target dir.
fn find_target_dir(manifest: &Path) -> PathBuf {
    // If CARGO_TARGET_DIR is set, honour it.
    if let Ok(d) = env::var("CARGO_TARGET_DIR") {
        return PathBuf::from(d);
    }
    // Otherwise assume <workspace-root>/target
    manifest
        .parent()
        .expect("manifest has no parent")
        .join("target")
}

// dma-latency-tracer-ebpf/src/main.rs
//
// eBPF program for per-DMA-transfer latency tracing on a Mellanox /
// ConnectX-5 25 Gbps SmartNIC (mlx5 driver).
//
// Architecture
// ────────────
// The mlx5 driver uses the kernel's DMA-mapping API:
//
//   dma_map_page()     ← kprobe entry  → record start timestamp
//   dma_unmap_page()   ← kprobe entry  → compute latency, emit event
//
// Both probes fire on the CPU that executes the mapping.  We stash
// the start timestamp in a per-CPU hash map keyed by the calling
// thread's PID+TID so that concurrent mappings on different CPUs do
// not collide.
//
// The completed event is written to a BPF ring buffer that userspace
// drains in a tight loop.
//
// Kernel tracepoints for DMA
// ──────────────────────────
// Linux ≥ 5.0 exposes:
//   trace/events/dma/  →  dma_map_page / dma_unmap_page
//
// We use kprobes instead of tracepoints so we can also capture the
// return value of dma_map_page (the DMA handle / bus address) which
// is only available at kretprobe time.
//
// Probe attachment plan
// ─────────────────────
//   kprobe  dma_map_page              → dma_map_page_enter
//   kretprobe dma_map_page            → dma_map_page_exit   (captures dma_addr)
//   kprobe  dma_unmap_page_attrs      → dma_unmap_page_enter
//
// The latency is measured as:
//   Δt = dma_unmap_page_enter.timestamp - dma_map_page_enter.timestamp
//
// This captures the time the DMA mapping is live, which includes:
//   • IOMMU page-table update
//   • Cache flush / SWIOTLB bounce (if active)
//   • PCIe transfer time (device access to the mapped region)
//   • Driver writeback / completion

#![no_std]
#![no_main]

use aya_bpf::{
    BpfContext,
    helpers::{bpf_get_current_pid_tgid, bpf_ktime_get_ns},
    macros::{kprobe, kretprobe, map},
    maps::{HashMap, RingBuf},
    programs::{ProbeContext, RetProbeContext},
};
use aya_log_ebpf::debug;
use common::{DmaDirection, DmaLatencyEvent};

// ── Maps ─────────────────────────────────────────────────────────────────────

/// Stash the entry timestamp while a dma_map_page call is in-flight.
/// Key = (pid << 32 | tid) so concurrent threads on different CPUs
/// each have their own slot.
#[map]
static DMA_START_MAP: HashMap<u64, u64> =
    HashMap::with_max_entries(8192, 0);

/// Stash the DMA address returned by dma_map_page so the unmap probe
/// can include it in the event.
#[map]
static DMA_ADDR_MAP: HashMap<u64, u64> =
    HashMap::with_max_entries(8192, 0);

/// Stash the byte-length of the mapping so the unmap probe can
/// include it in the event for throughput calculation.
#[map]
static DMA_LEN_MAP: HashMap<u64, u64> =
    HashMap::with_max_entries(8192, 0);

/// Stash the dma_data_direction enum value captured at map entry.
#[map]
static DMA_DIR_MAP: HashMap<u64, u8> =
    HashMap::with_max_entries(8192, 0);

/// Ring buffer shared with userspace.  4 MiB is enough to buffer
/// ~87 000 events before the consumer must drain it.
/// (4 * 1024 * 1024) / 48 bytes per event ≈ 87 381 events.
#[map]
static EVENTS: RingBuf = RingBuf::with_byte_size(4 * 1024 * 1024, 0);

// ── Helpers ───────────────────────────────────────────────────────────────────

/// Return a unique key for the current kernel thread.
#[inline(always)]
fn thread_key() -> u64 {
    // upper 32 bits = tgid (process), lower 32 bits = pid (thread)
    bpf_get_current_pid_tgid()
}

// ── kprobe: dma_map_page entry ────────────────────────────────────────────────
//
// Prototype (kernel):
//   dma_addr_t dma_map_page(struct device *dev, struct page *page,
//                           size_t offset, size_t size,
//                           enum dma_data_direction dir)
//
// Registers (x86-64 SystemV ABI / pt_regs):
//   rdi = dev, rsi = page, rdx = offset, rcx = size, r8 = dir

#[kprobe]
pub fn dma_map_page_enter(ctx: ProbeContext) -> u32 {
    match try_dma_map_page_enter(&ctx) {
        Ok(_)  => 0,
        Err(_) => 1,
    }
}

fn try_dma_map_page_enter(ctx: &ProbeContext) -> Result<(), i64> {
    let key = thread_key();
    let now = unsafe { bpf_ktime_get_ns() };

    // Argument 4 (index 3, 0-based) = size  (rcx on x86-64)
    let size: u64 = unsafe { ctx.arg(3) }.ok_or(1i64)?;

    // Argument 5 (index 4, 0-based) = direction  (r8 on x86-64)
    // enum dma_data_direction: DMA_BIDIRECTIONAL=0, DMA_TO_DEVICE=1,
    //                          DMA_FROM_DEVICE=2,  DMA_NONE=3
    let dir_raw: u32 = unsafe { ctx.arg(4) }.ok_or(1i64)?;
    let direction: u8 = match dir_raw {
        1 => DmaDirection::ToDevice   as u8,
        2 => DmaDirection::FromDevice as u8,
        _ => DmaDirection::ToDevice   as u8, // treat bidir as TX
    };

    // Store start timestamp, byte-length, and direction
    DMA_START_MAP.insert(&key, &now, 0).map_err(|e| e as i64)?;
    DMA_LEN_MAP  .insert(&key, &size, 0).map_err(|e| e as i64)?;
    DMA_DIR_MAP  .insert(&key, &direction, 0).map_err(|e| e as i64)?;

    Ok(())
}

// ── kretprobe: dma_map_page return ───────────────────────────────────────────
//
// Captures the DMA address (bus address) returned in RAX.

#[kretprobe]
pub fn dma_map_page_exit(ctx: RetProbeContext) -> u32 {
    match try_dma_map_page_exit(&ctx) {
        Ok(_)  => 0,
        Err(_) => 1,
    }
}

fn try_dma_map_page_exit(ctx: &RetProbeContext) -> Result<(), i64> {
    let key      = thread_key();
    let dma_addr: u64 = ctx.ret().ok_or(1i64)?;

    DMA_ADDR_MAP.insert(&key, &dma_addr, 0).map_err(|e| e as i64)?;
    Ok(())
}

// ── kprobe: dma_unmap_page_attrs entry ───────────────────────────────────────
//
// In Linux ≥ 5.x dma_unmap_page is an inline wrapper that calls
// dma_unmap_page_attrs.  We attach here so we get a stable kprobe site.
//
// Prototype:
//   void dma_unmap_page_attrs(struct device *dev, dma_addr_t addr,
//                             size_t size, enum dma_data_direction dir,
//                             unsigned long attrs)
//
// Registers (x86-64):
//   rdi=dev  rsi=addr(dma_addr_t)  rdx=size  rcx=dir  r8=attrs

#[kprobe]
pub fn dma_unmap_page_enter(ctx: ProbeContext) -> u32 {
    match try_dma_unmap_page_enter(&ctx) {
        Ok(_)  => 0,
        Err(_) => 1,
    }
}

fn try_dma_unmap_page_enter(ctx: &ProbeContext) -> Result<(), i64> {
    let key = thread_key();
    let end = unsafe { bpf_ktime_get_ns() };

    // Retrieve the start timestamp recorded by dma_map_page_enter.
    let start = match unsafe { DMA_START_MAP.get(&key) } {
        Some(t) => *t,
        None    => return Ok(()), // no matching entry; skip
    };

    if end < start {
        // Clock anomaly (rare on TSC, theoretically impossible with
        // ktime_get_ns on a modern kernel, but be defensive).
        let _ = DMA_START_MAP.remove(&key);
        let _ = DMA_ADDR_MAP .remove(&key);
        let _ = DMA_LEN_MAP  .remove(&key);
        let _ = DMA_DIR_MAP  .remove(&key);
        return Ok(());
    }

    let latency_ns     = end - start;
    let dma_addr       = unsafe { DMA_ADDR_MAP.get(&key) }.copied().unwrap_or(0);
    let transfer_bytes = unsafe { DMA_LEN_MAP .get(&key) }.copied().unwrap_or(0);
    let direction      = unsafe { DMA_DIR_MAP .get(&key) }.copied().unwrap_or(0);

    // Clean up scratch maps
    let _ = DMA_START_MAP.remove(&key);
    let _ = DMA_ADDR_MAP .remove(&key);
    let _ = DMA_LEN_MAP  .remove(&key);
    let _ = DMA_DIR_MAP  .remove(&key);

    // Read CPU id from pt_regs context helper (returns u64, take low 32 bits)
    let cpu = (unsafe { bpf_get_current_pid_tgid() } >> 32) as u32;
    // Note: bpf_get_smp_processor_id() is not directly exposed in aya-bpf
    // 0.13 helpers module without a raw call; use ctx.cpu() instead:
    #[allow(unused_variables)]
    let cpu: u32 = ctx.cpu();

    // Write to ring buffer
    let event = DmaLatencyEvent {
        start_ns:       start,
        end_ns:         end,
        latency_ns,
        transfer_bytes,
        dma_addr,
        cpu,
        direction,
        _pad:           [0u8; 3],
    };

    // Reserve space in the ring buffer.  If the consumer is slow and
    // the buffer is full we discard silently (BPF_RB_NO_WAKEUP flag
    // is NOT set here; we want immediate wakeup so userspace drains quickly).
    if let Some(mut entry) = EVENTS.reserve::<DmaLatencyEvent>(0) {
        entry.write(event);
        entry.submit(0);
    } else {
        debug!(&ctx, "ring buffer full – event dropped");
    }

    Ok(())
}

// ── Required eBPF panic handler ───────────────────────────────────────────────

#[panic_handler]
fn panic(_info: &core::panic::PanicInfo) -> ! {
    loop {}
}

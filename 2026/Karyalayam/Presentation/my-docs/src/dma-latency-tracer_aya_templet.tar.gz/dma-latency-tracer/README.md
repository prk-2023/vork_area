# dma-latency-tracer

**Per-DMA-transfer latency tracer for Mellanox ConnectX-5 SmartNIC (mlx5)**
using [Aya 0.13](https://aya-rs.dev/) (build.rs workflow, no xtask).

---

## Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                     Fedora 43 Host (PCIe 3.0)                       │
│                                                                     │
│  ┌───────────────┐        ┌──────────────────────────────────────┐  │
│  │  Network NS1  │        │   Mellanox ConnectX-5 SmartNIC       │  │
│  │  10.0.0.1/24  │◄──────►│   Port 0 ──DAC cable── Port 1       │  │
│  │    (Port 0)   │        │                    (Port 1)          │  │
│  └───────────────┘        └──────────────────────────────────────┘  │
│  ┌───────────────┐                      ▲                           │
│  │  Network NS2  │        ┌─────────────┴──────────────────────┐   │
│  │  10.0.0.10/24 │◄──────►│  DMA Latency Tracer (eBPF/Aya)     │   │
│  │    (Port 1)   │        │  kprobes on dma_map_page /         │   │
│  └───────────────┘        │  dma_unmap_page_attrs              │   │
│                           └────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

### What is measured?

The eBPF program measures the **DMA mapping lifetime** — the interval
between:

| Event | Kernel function | Meaning |
|---|---|---|
| Start | `dma_map_page()` entry | Driver creates DMA mapping; IOMMU TLB is updated |
| End   | `dma_unmap_page_attrs()` entry | DMA transfer complete; mapping torn down |

This latency includes:
- IOMMU/SMMU page-table update
- PCIe DMA transfer time (the device reading/writing host memory)
- Any SWIOTLB bounce-buffer copy (if IOMMU is in passthrough, usually absent for mlx5)
- Cache-coherency flush latency

On a PCIe 3.0 host with a 25 Gbps NIC the DMA transfer component for
a typical 2 KiB packet buffer is:

```
time ≈ bytes / bandwidth = 2048 B / (25e9 / 8) B/s ≈ 655 ns
```

The tracer lets you observe this empirically across all transfer sizes.

---

## Project structure

```
dma-latency-tracer/
├── Cargo.toml                    # Workspace
├── rust-toolchain.toml           # Pins nightly with bpfel target
├── .cargo/config.toml            # bpfel-unknown-none build flags
├── setup.sh                      # One-shot Fedora 43 setup
│
├── common/                       # Shared types (no_std)
│   ├── Cargo.toml
│   └── src/lib.rs                # DmaLatencyEvent, DmaStats, DmaDirection
│
├── dma-latency-tracer-ebpf/      # eBPF program (cross-compiled by build.rs)
│   ├── Cargo.toml
│   └── src/main.rs               # kprobe / kretprobe handlers + ring buffer
│
└── dma-latency-tracer/           # Userspace loader & reporter
    ├── Cargo.toml
    ├── build.rs                  # Cross-compiles eBPF crate, embeds ELF
    └── src/main.rs               # Loads BPF, drains ring buffer, prints dashboard
```

---

## Prerequisites

| Requirement | Notes |
|---|---|
| Fedora 43 | kernel ≥ 5.15, BTF enabled (`/sys/kernel/btf/vmlinux`) |
| mlx5_core driver | Ships with Fedora; verify with `lsmod | grep mlx5` |
| Rust nightly | Pinned in `rust-toolchain.toml` |
| `bpfel-unknown-none` target | `rustup target add bpfel-unknown-none` |
| clang / lld | `dnf install clang lld` |
| CAP_BPF + CAP_SYS_ADMIN | Run as root or grant capabilities |

---

## Setup

```bash
# 1. Run the one-shot setup script (root required)
sudo bash setup.sh

# If your interface names differ from enp1s0f0 / enp1s0f1:
sudo MLX_IF1=enp3s0f0np0 MLX_IF2=enp3s0f1np1 bash setup.sh
```

The script:
- Installs system packages (clang, llvm, bpftool, iproute)
- Installs nightly Rust + bpfel target via rustup
- Creates `ns1` / `ns2` network namespaces
- Assigns the two ConnectX-5 ports to the namespaces
- Assigns `10.0.0.1/24` and `10.0.0.10/24`
- Verifies ping connectivity across the DAC cable

---

## Build

```bash
cd dma-latency-tracer
cargo build --release
```

`build.rs` automatically cross-compiles the eBPF crate for
`bpfel-unknown-none` and embeds the resulting ELF as a byte slice.
The final binary is fully self-contained.

---

## Run

```bash
# Basic (1-second reporting interval)
sudo ./target/release/dma-latency-tracer

# With latency histogram
sudo ./target/release/dma-latency-tracer --histogram

# Report every 5 seconds, only show transfers ≥ 500 ns
sudo ./target/release/dma-latency-tracer --interval 5 --min-ns 500

# Generate traffic in another terminal to see real DMA activity:
ip netns exec ns1 iperf3 -s &
ip netns exec ns2 iperf3 -c 10.0.0.1 -t 60 -P 8
```

### Sample output

```
 ╔══ DMA Latency Tracer — Mellanox ConnectX-5 (mlx5) — PCIe 3.0 ══╗
 Timestamp : 1735000000 s (Unix epoch UTC)
 Interface : ConnectX-5 25GbE  │  Topology: ns1 ←DAC→ ns2
 ──────────────────────────────────────────────────────────────────
 TX (to-device  / host→NIC)
   Samples :      42 315    Bytes   : 85.23 MiB
   Avg lat :       1 203 ns   Min lat : 412 ns
   Max lat :      18 740 ns   Tput    : 0.681 Gbps
 RX (from-device / NIC→host)
   Samples :      41 892    Bytes   : 84.37 MiB
   Avg lat :       1 187 ns   Min lat : 398 ns
   Max lat :      22 190 ns   Tput    : 0.674 Gbps

 Combined DMA throughput : 1.355 Gbps  (169.60 MiB transferred)
 PCIe 3.0 x16 headroom  : 0.1%  (theoretical max ~125 GB/s)
```

---

## How it works (internals)

### eBPF maps

| Map | Type | Purpose |
|---|---|---|
| `DMA_START_MAP` | `HashMap<u64, u64>` | Entry timestamp keyed by `pid‖tid` |
| `DMA_ADDR_MAP` | `HashMap<u64, u64>` | DMA bus address from `kretprobe` |
| `DMA_LEN_MAP` | `HashMap<u64, u64>` | Transfer byte count |
| `DMA_DIR_MAP` | `HashMap<u64, u8>` | DMA direction (TX / RX) |
| `EVENTS` | `RingBuf` (4 MiB) | Completed events → userspace |

### Probe sites

```
dma_map_page (kprobe entry)
  └─ Record: start_ns, size, direction  →  DMA_START_MAP / DMA_LEN_MAP / DMA_DIR_MAP

dma_map_page (kretprobe return)
  └─ Record: dma_addr (RAX)  →  DMA_ADDR_MAP

dma_unmap_page_attrs (kprobe entry)
  └─ Lookup: start_ns, dma_addr, size, direction
  └─ Compute: latency_ns = now - start_ns
  └─ Emit: DmaLatencyEvent  →  EVENTS ring buffer
  └─ Cleanup: remove all scratch map entries
```

### Ring buffer

The 4 MiB `RingBuf` holds up to ~87 000 events before overflow.
Userspace polls every 100 µs.  With 25 Gbps of traffic and ~1500-byte
packets there are ~2 million packets/s → ~4 million DMA operations/s
(one map + one unmap per packet buffer).  The ring buffer will overflow
under full line rate; consider increasing its size or adding a sampling
filter in the eBPF program for production use.

---

## Tuning for high throughput

For full 25 Gbps line-rate tracing, increase the ring buffer and add
a 1-in-N sampling filter:

```rust
// In dma-latency-tracer-ebpf/src/main.rs – increase ring size:
static EVENTS: RingBuf = RingBuf::with_byte_size(64 * 1024 * 1024, 0); // 64 MiB

// Add sampling – only emit 1 in every 16 events:
static SAMPLE_COUNTER: PerCpuArray<u64> = PerCpuArray::with_max_entries(1, 0);
// … in dma_unmap_page_enter:
let cnt = SAMPLE_COUNTER.get_ptr_mut(0).ok_or(0)?;
*cnt = cnt.wrapping_add(1);
if *cnt & 0xF != 0 { return Ok(()); }
```

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `Failed to load eBPF ELF – are you running as root?` | Run with `sudo` |
| `kprobe attach failed for 'dma_map_page'` | `dma_map_page` is inlined; try `iommu_dma_map_page` or `swiotlb_map_page` |
| No events / zero samples | Ensure traffic is flowing: run iperf3 across the two namespaces |
| Ring buffer full – event dropped | Increase `RingBuf` size or add sampling (see Tuning section) |
| Build fails: `bpfel-unknown-none` not found | `rustup target add bpfel-unknown-none` |
| Build fails: `-Z build-std` not stable | Ensure nightly toolchain is active: `rustup default nightly` |

---

## License

MIT OR Apache-2.0

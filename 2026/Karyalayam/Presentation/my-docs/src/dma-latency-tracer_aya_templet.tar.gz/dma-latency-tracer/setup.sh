#!/usr/bin/env bash
# setup.sh – Prepare a Fedora 43 machine with a Mellanox ConnectX-5
# SmartNIC for the DMA latency tracer.
#
# Run once as root (or with sudo).
# Usage: sudo bash setup.sh
set -euo pipefail

##############################################################################
# 1. System packages
##############################################################################
echo "==> Installing system packages…"
dnf install -y \
    clang llvm lld \
    bpftool \
    kernel-devel \
    iproute \
    ethtool

##############################################################################
# 2. Rust toolchain
##############################################################################
echo "==> Installing Rust (nightly) via rustup…"
if ! command -v rustup &>/dev/null; then
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain none
    source "$HOME/.cargo/env"
fi

# rust-toolchain.toml in the project root will pin the exact channel.
# Install components needed for eBPF cross-compilation.
rustup toolchain install nightly-2024-11-01 \
    --component rust-src rustfmt clippy \
    --target bpfel-unknown-none x86_64-unknown-linux-gnu

##############################################################################
# 3. Kernel: enable BTF and BPF ring buffer (Fedora 43 default kernel
#    ships with both, but verify.)
##############################################################################
echo "==> Checking kernel BPF capabilities…"
if [[ ! -f /sys/kernel/btf/vmlinux ]]; then
    echo "WARNING: /sys/kernel/btf/vmlinux not found."
    echo "         Make sure CONFIG_DEBUG_INFO_BTF=y in your kernel config."
fi

# Raise memlock limit for BPF maps (needed for non-root aya programs;
# for root this is usually already unlimited).
echo "==> Setting memlock rlimit…"
ulimit -l unlimited || true

##############################################################################
# 4. Network namespaces and veth/physical ports
#
#    ConnectX-5 appears as two PFs under the mlx5 driver.
#    Adjust IF1/IF2 to the actual interface names shown by 'ip link'.
##############################################################################
IF1="${MLX_IF1:-enp1s0f0}"   # first port  → ns1
IF2="${MLX_IF2:-enp1s0f1}"   # second port → ns2

echo "==> Configuring network namespaces (ns1, ns2)…"
echo "    Using interfaces: IF1=$IF1  IF2=$IF2"
echo "    Override with: export MLX_IF1=<name> MLX_IF2=<name>"

# Create namespaces if they do not exist
for ns in ns1 ns2; do
    ip netns add "$ns" 2>/dev/null || true
done

# Move interfaces into namespaces
ip link set "$IF1" netns ns1
ip link set "$IF2" netns ns2

# Assign IP addresses and bring links up
ip netns exec ns1 ip addr add 10.0.0.1/24  dev "$IF1"
ip netns exec ns1 ip link set "$IF1" up

ip netns exec ns2 ip addr add 10.0.0.10/24 dev "$IF2"
ip netns exec ns2 ip link set "$IF2" up

echo "==> Network configuration:"
ip netns exec ns1 ip addr show "$IF1"
ip netns exec ns2 ip addr show "$IF2"

##############################################################################
# 5. Verify connectivity across the DAC cable
##############################################################################
echo "==> Testing connectivity (ns1 → ns2 via DAC cable)…"
if ip netns exec ns1 ping -c3 -W2 10.0.0.10 &>/dev/null; then
    echo "    Ping ns1→ns2: OK"
else
    echo "    WARNING: Ping failed.  Check the DAC cable and link state."
fi

##############################################################################
# 6. Check mlx5 driver version and firmware
##############################################################################
echo "==> mlx5 driver info:"
modinfo mlx5_core | grep -E "^(version|description|firmware)"

echo ""
echo "=================================================================="
echo " Setup complete."
echo " Build the tracer:  cargo build --release"
echo " Run the tracer:    sudo ./target/release/dma-latency-tracer"
echo "=================================================================="

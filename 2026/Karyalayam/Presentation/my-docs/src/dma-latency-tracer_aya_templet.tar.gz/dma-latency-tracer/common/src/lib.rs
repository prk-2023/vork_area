// common/src/lib.rs
//
// Types that are shared between the eBPF program and the userspace
// loader.  Must remain no_std compatible so the eBPF crate can use
// them without pulling in std.
//
// Layout notes
// ─────────────
// Every field is naturally aligned and the struct is marked
// #[repr(C)] so that the kernel and userspace agree on the memory
// layout regardless of compiler version.

#![no_std]

/// Direction of a DMA transfer as seen by the NIC driver.
#[repr(u8)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DmaDirection {
    /// Host → device  (TX descriptor ring writeback)
    ToDevice   = 0,
    /// Device → host  (RX buffer fill / completion)
    FromDevice = 1,
}

/// One DMA-transfer latency sample emitted to the ring buffer.
///
/// Size = 48 bytes (naturally aligned, no padding needed).
#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct DmaLatencyEvent {
    /// ktime_get_ns() timestamp when the DMA map was started
    /// (tracepoint dma_map_page or driver kprobe entry).
    pub start_ns: u64,

    /// ktime_get_ns() timestamp when the DMA unmap completed
    /// (tracepoint dma_unmap_page or driver kprobe return).
    pub end_ns: u64,

    /// Latency in nanoseconds (end_ns - start_ns).
    pub latency_ns: u64,

    /// Number of bytes transferred in this DMA operation.
    pub transfer_bytes: u64,

    /// PCI bus address produced by dma_map_page (the device-visible
    /// address, also called DMA handle).
    pub dma_addr: u64,

    /// CPU that executed the mapping call.
    pub cpu: u32,

    /// Direction: 0 = to-device (TX), 1 = from-device (RX).
    pub direction: u8,

    /// Padding to keep the struct 48 bytes and 8-byte aligned.
    pub _pad: [u8; 3],
}

// Safety: DmaLatencyEvent is Plain-Old-Data with no pointers.
unsafe impl Send for DmaLatencyEvent {}
unsafe impl Sync for DmaLatencyEvent {}

/// Statistics snapshot computed in userspace from the ring buffer.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct DmaStats {
    pub count:       u64,
    pub sum_ns:      u64,
    pub min_ns:      u64,
    pub max_ns:      u64,
    pub sum_bytes:   u64,
    /// Nanoseconds of total measurement window (wall-clock).
    pub window_ns:   u64,
}

impl DmaStats {
    pub fn avg_ns(&self) -> u64 {
        if self.count == 0 { 0 } else { self.sum_ns / self.count }
    }

    /// Throughput in bytes / second derived from sampled DMA transfers
    /// and the measurement window.
    pub fn throughput_bps(&self) -> u64 {
        if self.window_ns == 0 { return 0; }
        // bytes * 1_000_000_000 / window_ns  (avoid u64 overflow via u128)
        ((self.sum_bytes as u128 * 1_000_000_000u128)
            / self.window_ns as u128) as u64
    }

    /// Throughput in Gbps (1 Gbps = 125_000_000 bytes/s).
    pub fn throughput_gbps(&self) -> f64 {
        self.throughput_bps() as f64 / 125_000_000.0
    }
}

fn main() {
    let src = [1u8, 2, 3, 4, 5];
    let mut dst = [0u8; 5];
    dst.copy_from_slice(&src);
    println!("Safe copy: {:?}", dst);

    let src = [10u8, 20, 30, 40, 50];
    let mut dst = [0u8; 5];
    unsafe {
        std::ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
    println!("Unsafe copy (memcpy): {:?}", dst);
}
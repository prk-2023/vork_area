# SIMD and Vector Instructions: C vs Rust

This project teaches SIMD using a two-phase approach:

1. **Generic Concepts + C Code** – Low-level understanding and real intrinsics.
2. **Rust Equivalents + Benefits** – Memory-safe abstraction with similar performance.

## Structure

- `c_version/` – Contains NEON C examples.
- `rust_version/` – Rust equivalents using `core::arch::aarch64::*`.

## Build Rust version:
```bash
cd rust_version
cargo run --bin lab4_vector_memcpy
```

NOTE: Works on AArch64 hardware (e.g., Apple M-series or ARM Linux).
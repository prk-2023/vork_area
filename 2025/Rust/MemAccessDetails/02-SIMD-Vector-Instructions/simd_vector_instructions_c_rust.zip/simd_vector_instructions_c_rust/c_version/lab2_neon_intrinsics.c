#include <arm_neon.h>
#include <stdio.h>

int main() {
    uint8x16_t a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
    uint8x16_t b = vaddq_u8(a, a);
    uint8_t result[16];
    vst1q_u8(result, b);

    printf("NEON add result: ");
    for (int i = 0; i < 16; i++) {
        printf("%u ", result[i]);
    }
    printf("\n");
    return 0;
}
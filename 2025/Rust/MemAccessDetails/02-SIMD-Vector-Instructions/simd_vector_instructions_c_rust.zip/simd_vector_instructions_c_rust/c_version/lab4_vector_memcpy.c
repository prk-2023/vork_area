#include <arm_neon.h>
#include <stdio.h>
#include <string.h>

void neon_memcpy(uint8_t* dst, const uint8_t* src, size_t len) {
    for (size_t i = 0; i < len; i += 16) {
        uint8x16_t data = vld1q_u8(src + i);
        vst1q_u8(dst + i, data);
    }
}

int main() {
    uint8_t src[64] = {1};
    uint8_t dst[64] = {0};

    neon_memcpy(dst, src, 64);

    printf("Vectorized memcpy result: ");
    for (int i = 0; i < 64; i++) {
        printf("%u ", dst[i]);
    }
    printf("\n");
    return 0;
}
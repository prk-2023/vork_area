#[cfg(target_arch = "aarch64")]
use core::arch::aarch64::*;

fn main() {
    #[cfg(target_arch = "aarch64")]
    unsafe {
        let a = vld1q_u8([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16].as_ptr());
        let b = vaddq_u8(a, a);
        let mut result = [0u8; 16];
        vst1q_u8(result.as_mut_ptr(), b);
        println!("NEON add result: {:?}", result);
    }

    #[cfg(not(target_arch = "aarch64"))]
    println!("NEON example only runs on AArch64 targets.");
}
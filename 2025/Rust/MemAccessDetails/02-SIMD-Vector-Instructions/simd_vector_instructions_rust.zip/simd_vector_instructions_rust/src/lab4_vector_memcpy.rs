#[cfg(target_arch = "aarch64")]
use core::arch::aarch64::*;

fn vectorized_memcpy(dst: &mut [u8], src: &[u8]) {
    assert!(dst.len() == src.len());
    assert!(dst.len() % 16 == 0);
    unsafe {
        for i in (0..src.len()).step_by(16) {
            let vec = vld1q_u8(src[i..].as_ptr());
            vst1q_u8(dst[i..].as_mut_ptr(), vec);
        }
    }
}

fn main() {
    let src = [1u8; 64];
    let mut dst = [0u8; 64];
    vectorized_memcpy(&mut dst, &src);
    println!("Vectorized memcpy result: {:?}", &dst[..]);
}
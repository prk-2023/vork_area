#[cfg(target_arch = "aarch64")]
use core::arch::aarch64::*;

fn main() {
    #[cfg(target_arch = "aarch64")]
    unsafe {
        let data = [10u8; 16];
        let reg = vld1q_u8(data.as_ptr());
        let mut out = [0u8; 16];
        vst1q_u8(out.as_mut_ptr(), reg);
        println!("LD1/ST1 simulated: {:?}", out);
    }

    #[cfg(not(target_arch = "aarch64"))]
    println!("This example only runs on AArch64 (NEON).");
}
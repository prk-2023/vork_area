fn main() {
    println!("SIMD = Single Instruction, Multiple Data");
    println!("Used to perform parallel computations on vectors of data.");
}
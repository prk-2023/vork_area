fn sum_vector(a: &[u8; 16], b: &[u8; 16]) -> [u8; 16] {
    let mut out = [0u8; 16];
    for i in 0..16 {
        out[i] = a[i] + b[i];
    }
    out
}

fn main() {
    let a = [1u8; 16];
    let b = [2u8; 16];
    let result = sum_vector(&a, &b);
    println!("Sum result: {:?}", result);
}
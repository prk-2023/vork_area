# SIMD and Vector Instructions in Rust (with AArch64 NEON)

This project explores SIMD (Single Instruction, Multiple Data) concepts using Rust and AArch64 NEON intrinsics.

## Labs

1. Introduction to SIMD concepts
2. NEON Intrinsics on AArch64
3. Common instructions (LD1, ST1, LDP, STP)
4. Vectorized memcpy using NEON
5. Assembly view of SIMD-optimized code

## Run a Lab
```bash
cargo run --bin lab1_intro_simd
```

## View Assembly
```bash
cargo rustc --bin lab5_asm_view -- --emit=asm
```

NOTE: These examples work best on AArch64 CPUs or via cross-compilation using NEON intrinsics.